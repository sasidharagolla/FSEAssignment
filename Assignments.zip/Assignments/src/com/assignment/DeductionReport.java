/**
 * 
 */
package com.assignment;


public class DeductionReport {

	 private int year;
	 private int startingSalary;
	 private int deductionfreq;
	 private int deduction;
	 private int deductionamount;
	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * @return the startingSalary
	 */
	public int getStartingSalary() {
		return startingSalary;
	}
	/**
	 * @param startingSalary the startingSalary to set
	 */
	public void setStartingSalary(int startingSalary) {
		this.startingSalary = startingSalary;
	}
	/**
	 * @return the deductionfreq
	 */
	public int getDeductionfreq() {
		return deductionfreq;
	}
	/**
	 * @param deductionfreq the deductionfreq to set
	 */
	public void setDeductionfreq(int deductionfreq) {
		this.deductionfreq = deductionfreq;
	}
	/**
	 * @return the deduction
	 */
	public int getDeduction() {
		return deduction;
	}
	/**
	 * @param deduction the deduction to set
	 */
	public void setDeduction(int deduction) {
		this.deduction = deduction;
	}
	/**
	 * @return the deductionamount
	 */
	public int getDeductionamount() {
		return deductionamount;
	}
	/**
	 * @param deductionamount the deductionamount to set
	 */
	public void setDeductionamount(int deductionamount) {
		this.deductionamount = deductionamount;
	}
	 
}
