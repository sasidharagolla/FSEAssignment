/**
 * 
 */
package com.assignment;


public class Prediction {
	 private int year;
	 private int startingSalary;
	 private int incementAmount;
	 private int deductionAmount;
	 private int salaryGrowth;
	/**
	 * @return the year
	 */
	public int getYear() {
		return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(int year) {
		this.year = year;
	}
	/**
	 * @return the startingSalary
	 */
	public int getStartingSalary() {
		return startingSalary;
	}
	/**
	 * @param startingSalary the startingSalary to set
	 */
	public void setStartingSalary(int startingSalary) {
		this.startingSalary = startingSalary;
	}
	/**
	 * @return the incementAmount
	 */
	public int getIncementAmount() {
		return incementAmount;
	}
	/**
	 * @param incementAmount the incementAmount to set
	 */
	public void setIncementAmount(int incementAmount) {
		this.incementAmount = incementAmount;
	}
	/**
	 * @return the deductionAmount
	 */
	public int getDeductionAmount() {
		return deductionAmount;
	}
	/**
	 * @param deductionAmount the deductionAmount to set
	 */
	public void setDeductionAmount(int deductionAmount) {
		this.deductionAmount = deductionAmount;
	}
	/**
	 * @return the salaryGrowth
	 */
	public int getSalaryGrowth() {
		return salaryGrowth;
	}
	/**
	 * @param salaryGrowth the salaryGrowth to set
	 */
	public void setSalaryGrowth(int salaryGrowth) {
		this.salaryGrowth = salaryGrowth;
	}
	 
	 
}
