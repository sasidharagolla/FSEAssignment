/**
 * 
 */
package com.assignment;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class IncomePrediction {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter starting salary..:");
		int startingSalary = input.nextInt();
		if(startingSalary <1)
		{
			System.out.println("Enter starting salary greater than 0");
			startingSalary = input.nextInt();
		}
		System.out.println("Enter increment to be received inpercent. do not enter % symbol:");
		int increment = input.nextInt();
		if(increment <0)
		{
			System.out.println("Do not enter negative values");
			increment = input.nextInt();
			
		}
		System.out.println("Enter Increment frequency:");
		int incementfreq = input.nextInt();
		if(incementfreq<1) {
			System.out.println("Enter Incement frequency greater than 0");
			incementfreq = input.nextInt();
		}
		System.out.println("Enter deduction amount:");
		int deductions = input.nextInt();
		if(deductions<0)
		{
			System.out.println("Do not enter negative values");
			deductions = input.nextInt();
			
		}
		System.out.println("Enter deduction frequency :");
		int deductionfreq = input.nextInt();
		if(deductionfreq<1) {
			System.out.println("Enter Deduction frequency greater than 0");
			deductionfreq = input.nextInt();
		}
		System.out.println("Enter prediction in years:");
		int prediction = input.nextInt();
		input.close();
		
		List<IncrementReport> incrementReport = new ArrayList<IncrementReport>();
		List<DeductionReport> deductionReport = new ArrayList<DeductionReport>();
		List<Prediction> Predictionreport = new ArrayList<Prediction>();
		for (int i=1;i<=prediction;i++) {
			
			IncrementReport incrementrpt = new IncrementReport();
			incrementrpt.setYear(i);
			incrementrpt.setStartingSalary(startingSalary);
			incrementrpt.setIncementfreq(incementfreq);
			incrementrpt.setIncrement(increment);
			int incrementamount = (((startingSalary*increment)/100))*incementfreq;
			incrementrpt.setIncrementamount(incrementamount);
			incrementReport.add(incrementrpt);

			DeductionReport deductionrpt = new DeductionReport();
			deductionrpt.setYear(i);
			deductionrpt.setStartingSalary(startingSalary);
			deductionrpt.setDeductionfreq(deductionfreq);
			deductionrpt.setDeduction(deductions);
			int decrementamount = (((startingSalary*deductions)/100))*deductionfreq;
			deductionrpt.setDeductionamount(decrementamount);
			deductionReport.add(deductionrpt);
			
			Prediction predictionrpt = new Prediction();
			predictionrpt.setYear(i);
			predictionrpt.setStartingSalary(startingSalary);
			predictionrpt.setIncementAmount(incrementamount);
			predictionrpt.setDeductionAmount(decrementamount);
			int salaryGrowth = startingSalary + incrementamount - decrementamount;
			predictionrpt.setSalaryGrowth(salaryGrowth);
			Predictionreport.add(predictionrpt);
			
			startingSalary=salaryGrowth;
		}
		
		System.out.println("Incement Report");
		System.out.println("----------------------------------------------------------------------------------------------------------");
	    System.out.printf("%5s %20s %20s %20s %20s", "Year", "Starting Salary", "Number of Increment ", "Increment%", "Increment Amount");
	    System.out.println();
	    System.out.println("-----------------------------------------------------------------------------------------------------------");
	    for(IncrementReport incremnt: incrementReport){
	        System.out.format("%5s %20s %20s %20d %20s",
	        		incremnt.getYear(), incremnt.getStartingSalary(), incremnt.getIncementfreq(), incremnt.getIncrement(), incremnt.getIncrementamount());
	        System.out.println();
	    }
	    System.out.println("------------------------------------------------------------------------------------------------------------");
	
	    System.out.println("Deduction Report");
	    System.out.println("----------------------------------------------------------------------------------------------------------");
	    System.out.printf("%5s %20s %20s %20s %20s", "Year", "Starting Salary", "Number of deductions ", "Deduction%", "Deduction Amount");
	    System.out.println();
	    System.out.println("-----------------------------------------------------------------------------------------------------------");
	    for(DeductionReport deductionrpt: deductionReport){
	        System.out.format("%5s %20s %20s %20d %20s",
	        		deductionrpt.getYear(), deductionrpt.getStartingSalary(), deductionrpt.getDeductionfreq(), deductionrpt.getDeduction(), deductionrpt.getDeductionamount());
	        System.out.println();
	    }
	    System.out.println("------------------------------------------------------------------------------------------------------------");
	    System.out.println("Prediction");
	    System.out.println("----------------------------------------------------------------------------------------------------------");
	    System.out.printf("%5s %20s %20s %20s %20s", "Year", "Starting Salary", "Increment amount ", "Deduction amaount", "Salary growth");
	    System.out.println();
	    System.out.println("-----------------------------------------------------------------------------------------------------------");
	    for(Prediction predictionrpt: Predictionreport){
	        System.out.format("%5s %20s %20s %20d %20s",
	        		predictionrpt.getYear(), predictionrpt.getStartingSalary(), predictionrpt.getIncementAmount(), predictionrpt.getDeductionAmount(), predictionrpt.getSalaryGrowth());
	        System.out.println();
	    }
	    System.out.println("------------------------------------------------------------------------------------------------------------");
	}

}
