/**
 * 
 */
package com.assignment;


public class IncrementReport {
 private int year;
 private int startingSalary;
 private int incementfreq;
 private int increment;
 private int incrementamount;
/**
 * @return the year
 */
public int getYear() {
	return year;
}
/**
 * @param year the year to set
 */
public void setYear(int year) {
	this.year = year;
}
/**
 * @return the startingSalary
 */
public int getStartingSalary() {
	return startingSalary;
}
/**
 * @param startingSalary the startingSalary to set
 */
public void setStartingSalary(int startingSalary) {
	this.startingSalary = startingSalary;
}
/**
 * @return the incementfreq
 */
public int getIncementfreq() {
	return incementfreq;
}
/**
 * @param incementfreq the incementfreq to set
 */
public void setIncementfreq(int incementfreq) {
	this.incementfreq = incementfreq;
}
/**
 * @return the increment
 */
public int getIncrement() {
	return increment;
}
/**
 * @param increment the increment to set
 */
public void setIncrement(int increment) {
	this.increment = increment;
}
/**
 * @return the incrementamount
 */
public int getIncrementamount() {
	return incrementamount;
}
/**
 * @param incrementamount the incrementamount to set
 */
public void setIncrementamount(int incrementamount) {
	this.incrementamount = incrementamount;
}
 

}
